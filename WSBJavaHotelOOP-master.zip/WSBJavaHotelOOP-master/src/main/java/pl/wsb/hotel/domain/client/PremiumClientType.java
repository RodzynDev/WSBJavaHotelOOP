package pl.wsb.hotel.domain.client;

public enum PremiumClientType {
    PREMIUM,
    PREMIUM_PLUS
}
