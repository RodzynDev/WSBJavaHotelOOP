package pl.wsb.hotel.domain.client;

public class ClientNotFoundException extends Exception {

    public ClientNotFoundException(String message) {
        super(message);
    }
}
