package pl.wsb.hotel.domain.hotel.room;

public class RoomNotFoundException extends Exception {

    public RoomNotFoundException(String message) {
        super(message);
    }
}
